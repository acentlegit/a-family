// Runtime Configuration
// This file is loaded BEFORE React app starts
// NOTE: API URL is now configured via REACT_APP_API_BASE in .env file
// No hardcoded IP addresses - all configuration via environment variables

window.ENV = {
  // API URL is now set via REACT_APP_API_BASE environment variable
  // This file kept for backward compatibility but not used
};
