// Runtime Configuration - LOCAL DEVELOPMENT
// This file is loaded BEFORE React app starts

window.ENV = {
  // Local Development: localhost
  REACT_APP_API_URL: 'http://localhost:5000/api'
};
